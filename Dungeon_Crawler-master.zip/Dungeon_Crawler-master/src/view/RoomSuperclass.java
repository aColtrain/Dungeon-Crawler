package view;

import javafx.scene.Node;
import javafx.scene.control.Button;

public abstract class RoomSuperclass {
    private int width;
    private int height;
    private Button northExit;
    private Button southExit;
    private Button westExit;
    private Button eastExit;
    private RoomSuperclass northRoom;
    private RoomSuperclass southRoom;
    private RoomSuperclass westRoom;
    private RoomSuperclass eastRoom;

    private Node hero;
    private Node monster1;

    public RoomSuperclass(int width, int height) {
        this.width = width;
        this.height = height;
        northExit = new Button("North Exit");
        southExit =  new Button("South Exit");
        westExit = new Button("West Exit");
        eastExit = new Button("East Exit");
    }
    public abstract void setMonster1Defeated(boolean monster1Defeated);
    public abstract void setMonster2Defeated(boolean monster2Defeated);
    public abstract void setMonster3Defeated(boolean monster3Defeated);
    public abstract boolean isMonster1Defeated();
    public abstract boolean isMonster2Defeated();
    public abstract boolean isMonster3Defeated();
    public abstract void removeMonster(int monster);
    public abstract int hasMonsters();
    public int getWidth() {
        return width;
    }
    public int getHeight() {
        return height;
    }
    public void setNorthRoom(RoomSuperclass northRoom) {
        this.northRoom = northRoom;
    }
    public void setSouthRoom(RoomSuperclass southRoom) {
        this.southRoom = southRoom;
    }
    public void setWestRoom(RoomSuperclass westRoom) {
        this.westRoom = westRoom;
    }
    public void setEastRoom(RoomSuperclass eastRoom) {
        this.eastRoom = eastRoom;
    }
    public RoomSuperclass getNorthRoom() {
        return northRoom;
    }
    public RoomSuperclass getSouthRoom() {
        return southRoom;
    }
    public RoomSuperclass getWestRoom() {
        return westRoom;
    }
    public RoomSuperclass getEastRoom() {
        return eastRoom;
    }
    public Button getNorthExit() {
        return northExit;
    }
    public Button getSouthExit() {
        return southExit;
    }
    public Button getWestExit() {
        return westExit;
    }
    public Button getEastExit() {
        return eastExit;
    }
    public abstract void setPlayerHPNum(int num);
    public abstract void setMonster1HPNum(int monster1HP);
    public abstract void setMonster2HPNum(int monster2HP);
    public abstract void setMonster3HPNum(int monster3HP);

    public abstract boolean getBeenRoom();

    public abstract Button getHealthPotion();

    public abstract Button getAttackPotion();

    public abstract Node getM1();

    public abstract Node getM2();

    public abstract Node getM3();
}