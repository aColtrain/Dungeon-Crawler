package view;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class WinScreen {
    private int width;
    private int height;
    private Label winner;

    public WinScreen(int width, int height) {
        this.width = width;
        this.height = height;
        winner = new Label("Congratulations!");
    }

    public Scene getScene() {
        VBox root = new VBox(winner);
        root.setAlignment(Pos.CENTER);
        Scene scene = new Scene(root, width, height);
        return scene;
    }

    public Label getWinner() {
        return winner;
    }
}
