package view;

public class Monster3 {
}
