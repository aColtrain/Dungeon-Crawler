package view;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;

public class StartScreen {
    private int width;
    private int height;
    private Button startButton;

    public StartScreen(int width, int height) {
        this.width = width;
        this.height = height;
        startButton = new Button("Start Game");
    }

    public Scene getScene() {
        VBox root = new VBox(startButton);
        root.setAlignment(Pos.CENTER);
        Scene scene = new Scene(root, width, height);
        return scene;
    }

    public Button getStartButton() {
        return startButton;
    }
}
