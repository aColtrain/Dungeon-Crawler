package view;

public class Monster2 {
}
