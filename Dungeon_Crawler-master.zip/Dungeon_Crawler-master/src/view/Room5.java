package view;

import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

public class Room5 extends RoomSuperclass {
    private Button northExit;
    private Button southExit;
    private Button westExit;
    private Button eastExit;
    private Label roomLabel;
    private RoomSuperclass northRoom;
    private RoomSuperclass southRoom;
    private RoomSuperclass westRoom;
    private RoomSuperclass eastRoom;
    private Group dungeon;
    private int playerHPNum;
    private int monster1HPNum;
    private int monster2HPNum;
    private int monster3HPNum;
    private Node hero;
    private Image heroImage;
    private static final String HERO_IMAGE_LOC =
            "http://icons.iconarchive.com/icons/raindropmemory/legendora/64/Hero-icon.png";
    private Node monster1;
    private Image monster1Image;
    private static final String MONSTER1_IMAGE =
            "https://i.pinimg.com/originals/c5/e0/3a/c5e03a15a08d595e0125b6f0d65908b2.gif";
    private Node monster2;
    private Image monster2Image;
    private static final String MONSTER2_IMAGE =
            "https://i.pinimg.com/originals/e1/ee/7f/e1ee7f0c504f30de0054cd6eed1a2581.gif";
    private Node axe;
    private Image axeImage;
    private static final String AXE_IMAGE =
            "https://preview.pixlr.com/images/800wm/100/1/1001468392.jpg";
    private Label playerHP;
    private Label monster1HP;
    private Label monster2HP;
    private Label monster3HP;
    private boolean beenRoom;
    private boolean monster1Defeated;
    private boolean monster2Defeated;
    private boolean monster3Defeated;
    private Button healthPotion;
    private Button attackPotion;
    private boolean weaponCollected;

    private VBox weaponBox;

    public Room5(int width, int height) {
        super(width, height);
        monster1Defeated = false;
        monster2Defeated = false;
        monster3Defeated = true;
        northExit = new Button("North Exit");
        southExit =  new Button("South Exit");
        westExit = new Button("West Exit");
        eastExit = new Button("East Exit");
        roomLabel = new Label("Room 5");
        axeImage = new Image(AXE_IMAGE);
        axe = new ImageView(axeImage);
        axe.setScaleX(.1);
        axe.setScaleY(.1);
        heroImage = new Image(HERO_IMAGE_LOC);
        hero = new ImageView(heroImage);
        monster1Image = new Image(MONSTER1_IMAGE);
        monster1 = new ImageView(monster1Image);
        monster1.setScaleX(.5);
        monster1.setScaleY(.5);
        monster2Image = new Image(MONSTER2_IMAGE);
        monster2 = new ImageView(monster2Image);
        monster2.setScaleX(.5);
        monster2.setScaleY(.5);
        healthPotion = new Button("Health Potion");
        attackPotion = new Button("Attack Potion");
    }

    public Scene getScene() {
        if (monster1Defeated && monster2Defeated && weaponCollected) {
            dungeon = new Group(hero);
        } else if (monster1Defeated && !monster2Defeated && !weaponCollected) {
            dungeon = new Group(hero, monster2, axe);
        } else if (!monster1Defeated && monster2Defeated && !weaponCollected) {
            dungeon = new Group(hero, monster1, axe);
        } else if (monster1Defeated && !monster2Defeated && weaponCollected) {
            dungeon = new Group(hero, monster2);
        } else if (!monster1Defeated && monster2Defeated && weaponCollected) {
            dungeon = new Group(hero, monster1);
        } else if (monster1Defeated && monster2Defeated && !weaponCollected) {
            dungeon = new Group(hero, axe);
        } else if (!monster1Defeated && !monster2Defeated && !weaponCollected) {
            dungeon = new Group(hero, monster1, monster2, axe);
        }
        VBox vbox = new VBox(healthPotion, attackPotion, westExit);
        vbox.setSpacing(20);
        BorderPane border = new BorderPane();
        border.setTop(northExit);
        border.setBottom(southExit);
        border.setLeft(vbox);
        border.setRight(eastExit);
        border.setCenter(dungeon);
        BorderPane.setAlignment(northExit, Pos.TOP_CENTER);
        BorderPane.setAlignment(southExit, Pos.BOTTOM_CENTER);
        BorderPane.setAlignment(vbox, Pos.CENTER_LEFT);
        BorderPane.setAlignment(eastExit, Pos.CENTER_RIGHT);
        Scene scene = new Scene(border, super.getWidth(), super.getHeight());
        return scene;
    }
    public Node getM1() {
        return monster1;
    }
    public Node getM2() {
        return monster2;
    }
    public Node getM3() {
        return null;
    }
    public Node getAxe() {
        return axe;
    }
    public void removeWeapon() {
        dungeon.getChildren().remove(axe);
    }
    public boolean isWeaponCollected() {
        return weaponCollected;
    }
    public void setWeaponCollected(boolean weaponCollected) {
        this.weaponCollected = weaponCollected;
    }
    public Button getHealthPotion() {
        return healthPotion;
    }
    public Button getAttackPotion() {
        return attackPotion;
    }
    public boolean monstersDead() {
        return isMonster1Defeated() && isMonster2Defeated() && isMonster3Defeated();
    }
    public boolean isMonster1Defeated() {
        return monster1Defeated;
    }
    public boolean isMonster2Defeated() {
        return monster2Defeated;
    }
    public boolean isMonster3Defeated() {
        return monster3Defeated;
    }
    public void setMonster1Defeated(boolean monster1Defeated) {
        this.monster1Defeated = monster1Defeated;
    }
    public void setMonster2Defeated(boolean monster2Defeated) {
        this.monster2Defeated = monster2Defeated;
    }
    public void setMonster3Defeated(boolean monster3Defeated) {
        this.monster3Defeated = monster3Defeated;
    }
    public void setBeenRoom(boolean beenRoom) {
        this.beenRoom = beenRoom;
    }
    public boolean getBeenRoom() {
        return beenRoom;
    }
    public void setPlayerHPNum(int num) {
        playerHPNum = num;
        playerHP = new Label("Player HP: " + num);
    }
    public void setMonster1HPNum(int num) {
        monster1HPNum = num;
        monster1HP = new Label("Monster 1 HP: " + num);
    }
    public void setMonster2HPNum(int num) {
        monster2HPNum = num;
        monster2HP = new Label("Monster 2 HP: " + num);
    }
    public void setMonster3HPNum(int num) {
        monster3HPNum = num;
        monster3HP = new Label("Monster 3 HP: " + num);
    }
    public void removeMonster(int monster) {
        if (monster == 1) {
            dungeon.getChildren().remove(monster1);
        } else if (monster == 2) {
            dungeon.getChildren().remove(monster2);
        }
    }
    public void addMonster(int monster) {
        if (monster == 1) {
            dungeon.getChildren().add(monster1);
        } else if (monster == 2) {
            dungeon.getChildren().add(monster2);
        }
    }
    public int hasMonsters() {
        return 4;
    }
    public Button getNorthExit() {
        return northExit;
    }
    public Button getSouthExit() {
        return southExit;
    }
    public Button getWestExit() {
        return westExit;
    }
    public Button getEastExit() {
        return eastExit;
    }
    public RoomSuperclass getNorthRoom() {
        return northRoom;
    }
    public RoomSuperclass getSouthRoom() {
        return southRoom;
    }
    public RoomSuperclass getWestRoom() {
        return westRoom;
    }
    public RoomSuperclass getEastRoom() {
        return eastRoom;
    }
    public void setNorthRoom(RoomSuperclass northRoom) {
        this.northRoom = northRoom;
    }
    public void setSouthRoom(RoomSuperclass southRoom) {
        this.southRoom = southRoom;
    }
    public void setWestRoom(RoomSuperclass westRoom) {
        this.westRoom = westRoom;
    }
    public void setEastRoom(RoomSuperclass eastRoom) {
        this.eastRoom = eastRoom;
    }
}