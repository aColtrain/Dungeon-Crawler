package view;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class Shop {
    private int width;
    private int height;
    private Button inventory;
    private Button buyHealth;
    private Button buyAttack;
    private Button buySword;
    private Button buyAxe;
    private Button buyShield;
    private Button buyTorch;
    private Button buyBowAndArrow;
    //private Text moneyLabel;
    private int money;

    public Shop(int width, int height) {
        this.width = width;
        this.height = height;
        inventory = new Button("Inventory");
        buyHealth = new Button("Buy Health Potion");
        buyAttack = new Button("Buy Attack Potion");
        buySword = new Button("Buy Sword");
        buyAxe = new Button("Buy Axe");
        buyShield = new Button("Buy Shield");
        buyTorch = new Button("Buy Torch");
        buyBowAndArrow = new Button("Buy Bow and Arrow");

    }

    public Scene getScene() {
        HBox potions = new HBox(buyHealth, buyAttack);
        potions.setSpacing(10);
        HBox weapons = new HBox(buySword, buyAxe, buyShield, buyTorch, buyBowAndArrow);
        weapons.setSpacing(10);
        VBox root = new VBox(potions, weapons);
        root.setSpacing(10);
        Scene scene = new Scene(root, width, height);
        return scene;
    }

    public Button getInventory() {
        return inventory;
    }

    public void setMoney(int money) {
        this.money = money;
        //moneyLabel = new Text("Money: $" + money);
    }

    public Button getBuyAttack() {
        return buyAttack;
    }

    public Button getBuyAxe() {
        return buyAxe;
    }

    public Button getBuySword() {
        return buySword;
    }

    public Button getBuyHealth() {
        return buyHealth;
    }

    public Button getBuyBowAndArrow() {
        return buyBowAndArrow;
    }

    public Button getBuyShield() {
        return buyShield;
    }

    public Button getBuyTorch() {
        return buyTorch;
    }
}