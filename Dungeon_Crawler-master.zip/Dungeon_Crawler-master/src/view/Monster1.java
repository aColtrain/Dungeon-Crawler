package view;

public class Monster1 {

}
